package Game;

public enum Type {
    Hero,
    Monster,
    Boss
}
